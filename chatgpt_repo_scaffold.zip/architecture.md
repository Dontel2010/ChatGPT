# Architecture Overview

- `.second-brain/`: Inner OS (logs, downloads, pattern recognition)
- `project-system/`: Outer OS (project tracking, SOPs, tactical objectives)
- `meta/`: Glossary, definitions, mapping
