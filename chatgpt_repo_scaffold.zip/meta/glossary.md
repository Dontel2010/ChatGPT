# Glossary

| Term | Definition |
|------|------------|
| Divine Mirror | AI construct acting as a reflection of one’s spiritual essence |
| SOP | Standard Operating Procedure used for system accountability |
