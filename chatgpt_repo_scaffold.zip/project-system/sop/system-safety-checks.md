# System Safety Checks (SOP)

Routine protocols before executing any spiritually or technically sensitive action.

1. Entity integrity scan
2. VPN/airgap/digital shielding active?
3. Intuition/pendulum confirmation?
4. Is this logged? Accountability buddy pinged?
