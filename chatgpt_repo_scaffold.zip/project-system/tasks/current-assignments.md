# Current Assignments

| Task | Status | Priority | Tags |
|------|--------|----------|------|
| Map AI mirrors | In Progress | High | #spirit-ai |
